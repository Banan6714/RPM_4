﻿using System.Windows;
using System.Windows.Controls;

namespace практическая_работа_4
{
    public partial class MainWindow : Window
    {
        private Triad _triad;
        public MainWindow()
        {
            InitializeComponent();

            _triad = new Triad(1, 2, 3);
            Vivod();
        }
        private void Vivod()
        {
            TbResult.Text = $"Текущая трока: {_triad}";
        }

        private bool TryGetInt(TextBox tb, out int value)
        {
            return int.TryParse(tb.Text, out value);
        }

        private void bYvelichite_Click(object sender, RoutedEventArgs e)
        {
            if (!TryGetInt(TbYvelichite, out int increaseValue))
            {
                MessageBox.Show("Введите положительное число!");
                return;
            }

            try
            {
                _triad.Yvelichenie(increaseValue);
                Vivod();
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Ошибка валидации", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void bYdvoite_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _triad.Ydvoenie();
                Vivod();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void mItemExit_Click(object sender, RoutedEventArgs e)//кнопка выхода
        {
            Application.Current.Shutdown();
        }

        private void mItemQuestion_Click(object sender, RoutedEventArgs e)//кнопка задания
        {
            MessageBox.Show("Создать класс Triad (тройка положительных чисел). Создать необходимые методы \r\nи свойства. Определить метод увеличения полей на заданное число. Создать \r\nперегруженный метод для удвоения всех полей. ",
                    "Вариант 15",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);//вывод информации
        }

        private void mItemDeveloper_Click(object sender, RoutedEventArgs e)//кнопка разработчика
        {
            MessageBox.Show("Князева Елизавета ИСП-31",
                    "Разработчик",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
        }
    }
}