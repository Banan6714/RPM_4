﻿namespace практическая_работа_4
{
    public class Triad
    {
        private int _a, _b, _c;
        /// <summary>
        /// //////////////ЗАКОМЕНТИТЬ ВСЕ МЕТОДЫ И Т Д
        /// </summary>
        public int A
        {
            get => _a;
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Значение должно быть положительным!");
                }
                _a = value;
            }
        }

        public int B
        {
            get => _b;
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Значение должно быть положительным!");
                }
                _b = value;
            }
        }

        public int C
        {
            get => _c;
            set
            {
                if (value <= 0) 
                {
                    throw new ArgumentException("Значение должно быть положительным!");
                }_c = value;
            }
        }

        public Triad(int a, int b, int c)
        {
            A = a;
            B = b;
            C = c;
        }

        // увеличивает все числа на заданное число
        public void Yvelichenie(int chislo)
        {
            if (A + chislo <= 0 || B + chislo <= 0 || C + chislo <= 0)
            {
                throw new ArgumentException("После увеличения числа не должны быть отрицательными!");
            }

            A += chislo;
            B += chislo;
            C += chislo;
        }

        // перегруженный метод для удвоения всех полей
        public void Ydvoenie()
        {
            A *= 2;
            B *= 2;
            C *= 2;
        }

        // вывод
        public override string ToString()
        {
            return $"({A}, {B}, {C})";
        }
    }
}
